/*5.	Fa�a um programa que leia uma matriz 5 x 5, bem como um valor X. O programa dever� fazer uma busca desse valor na matriz e, 
ao final, escrever a localiza��o (linha e coluna) ou uma mensagem de "n�o encontrado".*/
#include <stdio.h>
#include <locale.h>
#define max 3
int main()
{	setlocale(LC_ALL,"portuguese");
	int M[max][max], x, flag=0, lin, col;
	//lin e col foram declaradas para calcular o n�mero de posi��es pesquisadas
	printf("\n\t\tEntre com os %d valores para uma matriz %dx%d\n ", max*max,max,max); 
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
		{
			//Leitura dos dados
			printf("\nDigite o valor para a matriz[%d][%d]: ",i,j); 
			scanf("%d", &M[i][j]);
			//verifica se o dado lido � o maior at� o momento
		}
	}
	 
	//percorre a matriz a fim de imprimi-la 
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
			//imprime o elemento 
			printf("\t[%d]", M[i][j]);
		
		//salta uma linha 
		printf ("\n");
	}
	
	printf("\n\t\tDigite um valor para ser pesquisado na matriz: ");
	scanf("%d",&x);
	
	//percorre a matriz para encontrar o elemento x
	//flag � uma vari�vel usada como tipo l�gico. Incialmente � Falso (0) para representar que o elemento n�o foi encontrado
	//caso elemento encontrado, o status l�gico � alterado para encontrado, valor 1.
	//os la�os s�o repetidos de 0 a < max, enquanto flag==0.
	//Use com muito crit�rio <condi��es> em la�o for, visto que outras estruturas (while e do-while) podem ser mais apropriadas.
	for (lin = 0; lin <max && flag==0; lin++)
	{
		for (col = 0; col <max && flag==0; col++)
		{
			if (M[lin][col]==x)
				flag=1;
		}	
	}
	
	if (flag==1)
		printf("\n\tElemento %d encontrado na posi��o [%d][%d]", M[lin][col], lin,col);
	else
		printf("\n\tElemento %d n�o encontrado na matriz", x);
	
	//Apresenta o total de posi��es percorridas. Isso � poss�vel por meio do uso de flag no la�o for.
	printf("\n\tTotal de posi��es pesquisadas: %d", lin*col);
		
	//system ("pause"); 
	return 0;
}
