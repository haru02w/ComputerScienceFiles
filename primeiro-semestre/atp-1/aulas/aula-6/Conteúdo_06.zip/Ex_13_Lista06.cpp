/*13.	Construa um programa para ler dados e armazenar em duas matrizes inteiras, nomeadas como A e B. 
As dimens�es das matrizes s�o 3x3. Armazenar em uma matriz R o resultado da multiplica��o de A por B. 
Um exemplo de uma multiplica��o envolvendo uma matriz A de ordem 2 x 3 por uma matriz B de ordem 3 x 2 �:*/
#include <stdio.h>
#include <stdlib.h>
#include <locale.h> //Inclui a biblioteca para uso de localidade para o SO
#include <time.h> //biblioteca necess�ria para a fun��o time
#define linha_A 3
#define coluna_A 3
#define linha_B 3
#define coluna_B 3

int main()
{
	int A[linha_A][coluna_A], B[linha_B][coluna_B], R[linha_A][coluna_B];
	
	setlocale(LC_ALL,"Portuguese"); //localidade padr�o, mostra corretamente acentua��o e 
	srand(time(NULL));
	//Condi��o para multiplicar as matrizes: a dimens�o da coluna A deve ser igual a dimens�o da linha B
	if (coluna_A == linha_B)
	{
		printf("\nValores para a matriz A: ");
		for (int i=0; i<linha_A; i++)
		{
			for(int j=0; j<coluna_A; j++)
			{
				A[i][j]=rand()%10;//gera n�meros aleat�rios entre 0 e 10
				printf("\nElemento [%d][%d]: %d", i, j,A[i][j]);	
				//scanf("%d", &A[i][j]);
				
			}	
		}
		printf("\nValores para a matriz B: ");
		for (int i=0; i<linha_B; i++){
		
			for(int j=0; j<coluna_B; j++)
			{
				B[i][j]=rand()%10;//gera n�meros aleat�rios entre 0 e 10
				printf("\nElemento [%d][%d]: %d", i, j,B[i][j]);	
				//scanf("%d", &B[i][j]);
			
			}	
		}
		
		printf("\n\t\tAs matrizes geradas foram: ");
		printf("\n\tMatriz A\n ");
		//Apresenta��o
		for (int i = 0; i <linha_A; i++)
		{
			for (int j = 0; j <coluna_A; j++)
			//imprime o elemento 
				printf("\t[%d]", A[i][j]);
		
			//salta uma linha 
			printf ("\n");
		}
	
		//Apresenta��o
		printf("\n\tMatriz B \n ");
		for (int i = 0; i <linha_B; i++)
		{
			for (int j = 0; j <coluna_B; j++)
				//imprime o elemento 
				printf("\t[%d]", B[i][j]);
		
			//salta uma linha 
			printf ("\n");
		}
		//Inicializar a matriz R para acumular os valores
		for (int i=0; i<linha_A; i++)
		{
			for(int j=0; j<coluna_B; j++)
			{
				R[i][j] = 0;
			}
		}
		//Para a multiplica��o, � necess�rio fixar i e j, e variar K em fun��o da Coluna A
		//A coluna A define a quantidade de multiplica��es
		for (int i=0; i<linha_A; i++)
		{
			for(int j=0; j<coluna_B; j++)
			{
				for(int k=0; k<coluna_A; k++)
				{
					R[i][j] = R[i][j] + A[i][k]*B[k][j];
				}
			}	
		}
		//Apresenta o resultado
		printf("\nResultado da multiplica��o - Matriz A * Matriz B\n ");
		for (int i=0; i<linha_A; i++)
		{
			for(int j=0; j<coluna_B; j++)
			{
				printf("\t[%d]", R[i][j]);
			}
			printf("\n");
		}
	}
	else
		printf("\nO n�mero de elementos da coluna A precisa ser igual ao da linha B");
	 //system ("pause");
	return 0;
	
}
