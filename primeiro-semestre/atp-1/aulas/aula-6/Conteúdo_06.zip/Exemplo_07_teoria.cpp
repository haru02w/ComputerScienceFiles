#include <stdio.h>
#define n 2
#define m 3
int main()
{
	int A[][m]={{},{}};
	printf("\n\t\tValores matriz A:\n ");
	for (int i=0; i<n; i++)
	{	for(int j=0; j<m; j++)
			printf("\t[%d]", A[i][j]);
		printf("\n");
	}
	return 0;	
}

