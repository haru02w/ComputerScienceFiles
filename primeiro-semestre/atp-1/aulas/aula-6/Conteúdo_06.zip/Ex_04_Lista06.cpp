/*4.	Fa�a um programa que leia uma matriz 4 x 4, imprima a matriz e retorne
 a localiza��o (linha e a coluna) do maior valor.*/
#include <stdio.h>
#include <locale.h>
#define max 4
int main()
{	setlocale(LC_ALL,"portuguese");
	int M[max][max], maior_i, maior_j, maior_valor;
	printf("\n\t\tEntre com os %d valores para uma matriz %dx%d\n ", max*max,max,max); 
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
		{
			//Leitura dos dados
			printf("\nDigite o valor para a matriz[%d][%d]: ",i,j); 
			scanf("%d", &M[i][j]);
			//verifica se o dado lido � o maior at� o momento

			if (i==0)
			{//Armazena dados para inicializar 
				maior_valor = M[i][j];
				maior_i = i; 
				maior_j = j;
			}
			else if (M[i][j] > maior_valor)
			{
				//Atualiza dados somente quando o valor � maior 
				maior_valor = M[i][j];
				maior_i = i; 
				maior_j = j;
			}
		}
	}
	//percorre a matriz a fim de imprimi-la 
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
			//imprime o elemento 
			printf("\t[%d]", M[i][j]);
		
		//salta uma linha 
		printf ("\n");
	}
	printf("\nMaior valor: %d: ", maior_valor); 
	printf("\nlocalizado na linha : %d", maior_i ); 
	printf("\nlocalizado na coluna: %d", maior_j );
	//system ("pause"); 
	return 0;
}
