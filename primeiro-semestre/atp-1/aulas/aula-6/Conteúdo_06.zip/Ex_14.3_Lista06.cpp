/*14.3. Um programa em que usu�rio pode fornecer uma sequ�ncia de cidades at� que as cidades origem e destino sejam iguais.
 Apresente o tempo parcial requerido para percorrer as cidades, bem como o total para cumprir o percurso especificado.*/
#include <stdio.h>
#include <locale.h>
#define d 7
int main()
{
	setlocale(LC_ALL,"Portuguese");
	int tempo[d][d]={
	{0,2,11,6,15,11,1},
	{2,0,7,12,4,2,15},
	{11,7,0,11,8,3,13},
	{6,12,11,0,10,2,1},
	{15,4,8,10,0,5,13},
	{11,2,3,2,5,0,14},
	{1,15,13,1,13,14,0}
	};
	int origem, destino, acum=0, flag=1;//Vari�vel que tem a fun��o de estabelecer uma situa��o l�gica. Neste caso, o valor � True
	printf("\n\n\t\t\t  - Matriz de tempos -");    	
	for(int i=0; i<d; i++)
	{
		printf("\n");
		for(int j=0; j<d; j++)
			printf("\t [%d]",tempo[i][j]);
	}
	
  	do{
    	printf("\n\n");
    	if (flag==1) // Vari�vel l�gica que permite tratar a primeira entrada para origem e destino.
   		{	
      		do{
        		printf("\nDigite a cidade de origem: ");
        		scanf("%d",&origem);
        		if (origem<0 || origem>d-1)
       		     	printf("\nPosi��o fora do intervalo da matriz");
        	
      		}while(origem<0 || origem>d-1);
      		flag=0; //ap�s entrada v�lida de origem, altera o estado l�gico da vari�vel para n�o ler origem na pr�xima vez.
   		} 
   		else // Flag = 0, falso, que permite tornar, a partir da segunda entrada, o �ltimo destino como origem para o pr�ximo roteiro.
       		origem=destino;
      	do{
      		printf("\nDigite a cidade de destino: ");
      		scanf("%d",&destino);
      		if (destino<0 || destino>d-1)
      	    	printf("\nPosi��o fora do intervalo da matriz");
      		
    	}while(destino<0 || destino>d-1);
      
    	if (origem!=destino)
    	{
      		acum+=tempo[origem][destino]; //acumula os tempos.
      		printf("\n%d Tempo parcial (s)\n\n", acum); // mostra o tempo entre origem e destino
       	}
  
  	}while(origem!=destino);
  	printf("\n Tempo final: %d \n\n", acum); 
  	//system (PAUSE)
  
  	return 0; 
}

