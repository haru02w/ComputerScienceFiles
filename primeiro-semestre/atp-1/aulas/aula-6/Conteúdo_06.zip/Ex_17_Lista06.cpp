/*
17.	Fa�a um programa para armazenar as informa��es de 100 alunos. O programa
deve permitir entradas do nome, n�mero de matr�cula, tipo de curso (0 ou 1), n�mero do curso e a m�dia 
geral de cada aluno. Como resultado, o programa deve apresentar: (a) todas as informa��es armazenadas; 
(b) n�mero de matr�cula de cada aluno vinculado ao tipo de curso 1; (b) nome e n�mero de matr�cula de cada aluno 
vinculado ao tipo de curso 1, do n�mero do curso indicado pelo usu�rio e que obteve a melhor m�dia.*/

#include <stdio.h>
#include <locale.h>
#define n_alunos 2
//n_alunos deve ser 100

int main() 
{
	setlocale(LC_ALL,"Portuguese");
	char nome[n_alunos][40];
	int matricula[n_alunos], tipo_curso[n_alunos], n_curso[n_alunos], curso, ind_aux=-1, flag=0;
	float media[n_alunos];

	
	for (int i = 0; i < n_alunos; i++) {
		
		printf ("\n\t\t\tInforma��es do %do. Aluno: ", i + 1);
		
		printf ("\n\tNome do aluno: ");
		scanf(" %[^\n]s", nome[i]);
		
		do {
			
			printf ("\n\tMatr�cula: ");
			scanf ("%d", &matricula[i]);
						
			if (matricula[i] < 0)
				printf ("\n\tMatr�cula inv�lida. Tente novamente!");
			
		} while (matricula[i] < 0);
		
		do {
			
			printf ("\n\tTipo de curso (0 ou 1): ");
			scanf ("%d", &tipo_curso[i]);
						
			if (tipo_curso[i] != 1 && tipo_curso[i] != 0)
				printf ("\n\t\tEntrada inv�lida. Tente novamente!");
			
		} while (tipo_curso[i]  != 1 && tipo_curso[i] != 0);
		
		do {
			
			printf ("\n\tN�mero do curso: ");
			scanf("%d", &n_curso[i]);
			if (n_curso[i] < 0)
			    printf ("\n\t\tCurso inv�lido. Tente novamente!");
			
		} while (n_curso[i] < 0);
		
		do {
			
			printf ("\n\tM�dia: ");
			scanf ("%f", &media[i]);
						
			if (media[i] < 0)
				printf ("\n\t\tEntrada inv�lida. Tente novamente!");
			
		} while (media[i] < 0);
		
	}
	
	printf ("\n\n\tNome - Matr�cula (Ma) - Tipo de Curso (Tc) - N�mero do Curso (Cs) - M�dia (Me)\n\n");

	//item a
	for (int i = 0; i < n_alunos; i++)
		printf ("\n\t\tNo: %s | Ma: %d | Tc: %d | Cs: %d | Me: %.2f", nome[i], matricula[i], tipo_curso[i], n_curso[i], media[i]);

	//item b
	printf ("\n\n\n\t\tMatr�culas dos alunos, com tipo de curso igual a 1: ");
	for (int i = 0; i < n_alunos; i++)
	{
		if (tipo_curso[i] == 1)
			printf ("\n\t\tMatr�cula: %d", matricula[i]);
	}

	//item c
	do {
		printf ("\n\t\tDigite o c�digo de um curso para pesquisa: ");
		scanf ("%d", &curso);
		
		if (curso < 0)
			printf ("\n\t\tEntrada inv�lida. Tente novamente!");
	} while (curso < 0);

	//(c) nome e n�mero de matr�cula de cada aluno do tipocurso igual a 1, do curso
    //indicado pelo usu�rio e que obteve a melhor m�dia.
    for (int i = 0; i < n_alunos; i++)
	{
		if (tipo_curso[i]== 1 && n_curso[i]==curso)
		{
			if (ind_aux==-1)
			    ind_aux=i;
		    else if (media[i]>media[ind_aux])
			    ind_aux=i;
		    else if (media[i]==media[ind_aux])
		        flag=1;
		       
		}
	}

	if (ind_aux==-1)
        printf("\n\tNenhum aluno encontrado com a condi��o aluno do tipo de curso igual a 1 e do n�mero de curso indicado pelo usu�rio!");		
    else if (flag==1)
    	printf("\n\tAs m�dias dos alunos s�o iguais!");		
	else
		printf ("\n\tMelhor aluno(a) do curso %d (tipo de curso %d): %s - m�dia: %.2f\n", curso, tipo_curso[ind_aux], nome[ind_aux], media[ind_aux]);
	
	return 0;
}

