#include <stdio.h>
#define l 5
#define m 20
int main()
{
	char n[l][m];
	int i;
	for(i=0; i<l; i++)
	{
		printf("Digite o %do. nome: ", i+1);
		scanf(" %[^\n]s", n[i]);
	}
	for(i=0; i<l; i++)
	{
		printf("\n%do. nome digitado: %s", i+1,n[i]);
	}
	//system("PAUSE");
	return 0;
}

