/*	14.1. Um programa para ler a tabela acima e informar ao usu�rio o tempo requerido para percorrer duas cidades: 
cidade origem e cidade destino. Essas cidades origem e destino s�o digitadas pelo usu�rio. Esse processo deve ser 
repetido at� o momento em que duas cidades iguais s�o digitadas (origem e destino). O programa deve permitir apenas
 entradas v�lidas;*/
#include <stdio.h>
#include <locale.h>
#define d 7
int main()
{
	setlocale(LC_ALL,"Portuguese");
	int tempo[d][d]={
	{0,2,11,6,15,11,1},
	{2,0,7,12,4,2,15},
	{11,7,0,11,8,3,13},
	{6,12,11,0,10,2,1},
	{15,4,8,10,0,5,13},
	{11,2,3,2,5,0,14},
	{1,15,13,1,13,14,0}
	};
	int origem, destino;
	printf("\n\n\t\t\t  - Matriz de tempos -");
	for(int i=0; i<d; i++)
	{
		printf("\n");
		for(int j=0; j<d; j++)
			printf("\t [%d]",tempo[i][j]);
	}
	
	do
	{
		printf("\n\n");
		do{
			printf("\nDigite a cidade de origem: ");
			scanf("%d",&origem);
			if (origem<0 || origem>d-1)
				printf("\nPosi��o fora do intervalo da matriz");
		}while(origem<0 || origem>6);
		
		do{
			printf("\nDigite a cidade de destino: ");
			scanf("%d",&destino);
			if (destino<0 || destino>d-1)
				printf("\nPosi��o fora do intervalo da matriz");
		}while(destino<0 || destino>d-1);
		
		if (origem!=destino)
			printf("\n O tempo total do percurso entre as cidades � de %d hora(s)",tempo[origem][destino]);
		
	}while(origem!=destino);
		
	return 0;	
}

