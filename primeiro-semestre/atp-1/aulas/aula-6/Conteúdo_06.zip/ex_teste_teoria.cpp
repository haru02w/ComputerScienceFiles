#include <stdio.h> 
//Exerc�cio (Teste 2)
#define d 3
int main()
{
	char velha[d][d] = {{' ','o','x'},
					   {'o','x','o'},
					   {'x',' ',' '}};
	
	for(int i=0; i<d; i++) 
	{
		for(int j=0; j<d; j++)
		{
		 	printf(" %c ",velha[i][j]);
		 	if (j<d-1)
		 		printf("|");
		}
		if (i<d-1)
			printf("\n---+---+---\n");
	}
	return 0;
}



