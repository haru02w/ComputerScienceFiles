#include <stdio.h>
#include <locale.h>
/*
23.	Construa um programa para reproduzir a sa�da indicada na imagem abaixo. Para tanto, use # define size 10 e 
as vari�veis nomeadas como: vari�veis simples, sendo i, c, f, d com os tipos int, char, float e double, respectivamente;
vetores, sendo vet_i, vet_c, vet_f e vet_d, com os tipos int, char, float e double, respectivamente; matrizes, 
sendo m_i, m_c, m_f e m_d, com os tipos int, char, float e double, respectivamente. O programa n�o deve usar la�os.*/
#define size 10
int main()
{ setlocale(LC_ALL,"portuguese");
  int i, vet_i[size], mat_i[size][size];
  char c, vet_c[size], mat_c[size][size];
  float f, vet_f[size], mat_f[size][size];
  double d, vet_[size], mat_d[size][size];
  	
  printf("\t\t --- TIPO ---|--- BYTES ---\n");
  printf("\n\tVari�veis simples - i, c, f, d");
  printf("\n\t\tint:\t %lu bytes\n", sizeof(i));
  printf("\t\tchar:\t %lu bytes\n", sizeof(c));
  printf("\t\tfloat:\t %lu bytes\n", sizeof(f));
  printf("\t\tdouble:\t %lu bytes\n", sizeof(d));
  
  printf("\n\tVari�veis homog�neas unidim. (vetor) - i[%d], c[%d], f[%d], d[%d]",size,size,size,size);
  printf("\n\t\tint:\t %lu bytes\n", sizeof(i)*size);
  printf("\t\tchar:\t %lu bytes\n", sizeof(c)*size);
  printf("\t\tfloat:\t %lu bytes\n", sizeof(f)*size);
  printf("\t\tdouble:\t %lu bytes\n", sizeof(d)*size);
  
  printf("\n\tVari�veis homog�neas bidimen. (matriz) - i[%d][%d], c[%d][%d], f[%d][%d], d[%d][%d]",size,size,size,size,size,size,size,size);
  printf("\n\t\tint:\t %lu bytes\n", sizeof(i)*size*size);
  printf("\t\tchar:\t %lu bytes\n", sizeof(c)*size*size);
  printf("\t\tfloat:\t %lu bytes\n", sizeof(f)*size*size);
  printf("\t\tdouble:\t %lu bytes\n", sizeof(d)*size*size);
  
  
  return 0;
}
