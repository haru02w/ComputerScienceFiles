/*6.	Fa�a um programa que gere n�meros aleat�rios entre 0 e 100 para preencher as posi��es
 de duas  matrizes com dimens�es 4 x 4. As matrizes devem ser nomeadas como A e B. Uma matriz C deve receber,
  em cada posi��o, o maior elemento nas posi��es correspondentes de A e B. Apresente as matrizes. */
#include<stdio.h>
#include<stdlib.h>
#include<time.h> //biblioteca necess�ria para a fun��o time
#include <locale.h>
#define max 4
int main()
{	
	setlocale(LC_ALL,"portuguese");
	int A[max][max], B[max][max],C[max][max];
	srand(time(NULL));
	
	printf("\n\t\tExerc�cio 6"); 
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
		{
			//n�mero aleat�rios
			
			A[i][j]=rand()%100; //gera valores entre 0 e 100
			B[i][j]=rand()%100; //gera valores entre 0 e 100
			printf("\nN�merdo gerado A[%d][%d]: %d ",i,j,A[i][j]); 
			printf("\nN�merdo gerado B[%d][%d]: %d ",i,j,B[i][j]); 
			if (A[i][j]>B[i][j])
				C[i][j]=A[i][j];
			else
				C[i][j]=B[i][j];
		}
	}
	printf("\n\t\tAs matrizes geradas foram: ");
	printf("\n\tMatriz A\n ");
	//Apresenta��o
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
			//imprime o elemento 
			printf("\t[%d]", A[i][j]);
		
		//salta uma linha 
		printf ("\n");
	}
	
	//Apresenta��o
	printf("\n\tMatriz B \n ");
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
			//imprime o elemento 
			printf("\t[%d]", B[i][j]);
		
		//salta uma linha 
		printf ("\n");
	}
	printf("\n\tMatriz C, considerando o maior valor nas posi��es correspondentes de A e B\n ");
	for (int i = 0; i <max; i++)
	{
		for (int j = 0; j <max; j++)
			//imprime o elemento 
			printf("\t[%d]", C[i][j]);
		
		//salta uma linha 
		printf ("\n");
	}
	//system ("pause"); 
	return 0;
}
