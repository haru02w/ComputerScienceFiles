/*3.	Construa um programa para preencher uma matriz 4 x 4 
com o produto do valor da linha e da coluna de cada elemento. Em seguida, imprima na tela a matriz.*/
#include <stdio.h>
#define n 4
int main() 
{
  int m[n][n];
  // cria a matriz e a imprime
  for(int i=0 ; i<n; i++)
  {
    for (int j=0; j<n; j++)
    {
      m[i][j] = i*j;
      printf(" %d",m[i][j]);
    }
    printf("\n");
  }
  return 0;
}


