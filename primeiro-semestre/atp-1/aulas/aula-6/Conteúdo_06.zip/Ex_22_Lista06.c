/*22.	Construa um programa para determinar a pr�xima jogada em um Jogo da Velha. 
Assumir que o tabuleiro � representado por uma matriz de 3 x 3, na qual cada posi��o representa
 uma das casas do tabuleiro. A matriz pode conter somente os valores -1, 0, 1. Estes valores representam
  uma casa contendo uma pe�a do jogador A (-1), uma casa vazia do tabuleiro (0), e uma casa contendo uma 
  pe�a do jogador B (1). Exemplo:*/
#include <stdio.h>

#define n 3

int main() 
{
  int jogo[][n]={{-1,-1,1},
			     { 1,-1,0},
 				 {-1, 1,1}};

/*  int jogo[][n]={ {-1,-1,1},
			        { 1,-1,1},
 				    {-1, 1,0}};	*/

/*  int jogo[][n]={ {-1,-1,0},
			        { 1,-1,1},
 				    {-1, 1,1}};	*/

/*  int jogo[][n]={{ 0,-1, 1},
			       {-1, 1,-1},
 				   {-1, 1, 1}};	*/

 /* int jogo[][n]={{ 1,-1, 0},
			       { 1,-1,-1},
 				   {-1, 1, 1}};	*/

	
  int pos_x = 0, pos_0 = 0, pos_livre = 0, iniciou, A=0, B=0;
  //Vari�veis A e B permitem indicar quem venceu ou empate
  
  
 //Escreve o status da matriz
  printf("\n Matriz:");
  for(int i = 0; i < n; i++)
  {
    printf("\n");
    for(int j = 0; j < n; j++)
	{
        printf("%d ",jogo[i][j]);
    }
  }
	
  //Escreve o jogo no terminal
  printf("\n Jogo da velha:");
  for(int i = 0; i < n; i++)
  {
    printf("\n");
    for(int j = 0; j < n; j++)
	{
      if(jogo[i][j] == -1)
        printf("X ");
      else if(jogo[i][j] == 1)
        printf("O ");
      else
        printf("- ");
    }
  }
  /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  Considerando uma solu��o em que � perguntado quem iniciou. A estrutura��o a seguir visa
  definir um modelo geral para conhecer quantas posi��es vazias existem e depois tratar as
  combina��es. Entretanto, nesse exemplo, estamos considerando apenas a situa��o indicada
  no exerc�cio, fato que simplifica todo o processo e poderia eliminar o uso da contagem de X e O.
  
  Tamb�m, uma solu��o diferente pode ser escrita a partir de quem foi o �ltimo a jogar.
  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
  
  
  //Verifica os totais de X, O e espa�os vazios na matriz
  for(int i = 0; i < n; i++)
  {
    for(int j = 0; j < n; j++)
	{
      if(jogo[i][j] == -1)//A
	    pos_x++;
      else if(jogo[i][j] == 1)//B
        pos_0++;
      else
        pos_livre++;//vazio
    }
  }
  
  printf("\nJogadas de A: %d", pos_x);
  printf("\nJogadas de B: %d", pos_0);
  printf("\nPosi��es livres: %d", pos_livre);
  
  
  printf("\n\nInforme o jogador que iniciou o jogo (-1 para X, jogador A, e 1 para O, jogador B): ");
  scanf("%d",&iniciou);

  
 
  printf("\n\n");
  //Verifica��o para conhecer as jogadas. Modelo geral
  for(int i = 0; i < n; i++)
  {
    for(int j = 0; j < n; j++)
	{
      //Caso o Jogador A tenha iniciado e existe um �nico espa�o vazio
      if(iniciou == -1 && pos_x == pos_0 && pos_livre == 1)
	  {
        if(jogo[i][j] == 0)
        {
		  	printf("Jogador A deve jogar na posi��o [%d] [%d]: ", i, j); 
		  	jogo[i][j]=-1;
      	}
      }
      //Caso o Jogador B tenha iniciado e existe um �nico espa�o vazio
      else if(iniciou == 1 && pos_x == pos_0 && pos_livre == 1)
	  {
        if(jogo[i][j] == 0)
        {
		    printf("Jogador B deve jogar posi��o [%d] [%d]", i, j);  
		    jogo[i][j]=1;
        }
      }
    }
  }
  ////Verifica��o do resultado - horizontal
  for(int i = 0; i < n; i++)
  {
    if (jogo[i][0] == -1 && jogo[i][1] == -1 && jogo[i][2] == -1)
        A=1;
    else if (jogo[i][0] == 1 && jogo[i][1] == 1 && jogo[i][2] == 1)        
        B=1;
  }
  ////Verifica��o do resultado - vertical
  for(int j = 0; j < n; j++)
  {
    if (jogo[0][j] == -1 && jogo[1][j] == -1 && jogo[2][j] == -1)
        A=1;
    else if (jogo[0][j] == 1 && jogo[1][j] == 1 && jogo[2][j] == 1)    
        B=1;
  }
  ////Verifica��o do resultado - diagonal principal
  if (jogo[0][0] == -1 && jogo[1][1] == -1 && jogo[2][2] == -1)
        A=1;
  else if (jogo[0][0] == 1 && jogo[1][1] == 1 && jogo[2][2] == 1)
        B=1;
        
  ////Verifica��o do resultado - diagonal secund�ria
  if (jogo[2][0] == -1 && jogo[1][1] == -1 && jogo[0][2] == -1)
        A=1;
  else if (jogo[2][0] == -1 && jogo[1][1] == -1 && jogo[0][2] == -1)
        B=1;
         
  //Apresentar resultado     
  if (A==0 && B==0)
     printf("\nPrevis�o: Empate!");
  else if (A==1)
     printf("\nPrevis�o: Jogador A (X) vencer�!");	  
  else 
  	 printf("\nPrevis�o: Jogador B (O) vencer�!");
  
  
  return 0;
}

