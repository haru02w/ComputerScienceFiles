/*2.	Construa um programa que cont�m uma matriz 5 x 5. Preencha com 1 a diagonal 
principal e com 0 os demais elementos. Escreva ao final a matriz obtida.*/
#include <stdio.h>
#define d 5
int main()
{   
  int M[d][d];

  for (int i = 0; i <d; i++)
  {
    for (int j = 0; j <d; j++)
    {
      //cria matriz identidade
      if (i == j)
        M[i][j] = 1;
      else
        M[i][j] = 0;
    
      //imprime o elemento da matriz
      printf("\t[%d]", M[i][j]);
    }
    //salta uma linha
    printf ("\n");
  }
  //system ("pause");
  return 0;
}

