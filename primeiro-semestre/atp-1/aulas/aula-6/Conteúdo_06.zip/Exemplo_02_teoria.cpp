#include <stdio.h>
#define m 3
#define n 4
int main() 
{
	int A[m][n], cont=0;

	for(int i=0; i<m; i++) //Um la�o para acessar as linhas da matriz A
	{
		putchar('\n');
		for(int j=0; j<n; j++)//Para cada linha i, um la�o para acessar as colunas correspondentes
		{	
			printf("[%d][%d] ", i, j);
			A[i][j]=cont;
			cont++;
		}
	}
	printf("\n\nConte�do da matriz A\n");
	for(int i=0; i<m; i++) //Um la�o para acessar as linhas da matriz A
	{
		putchar('\n');
		for(int j=0; j<n; j++)//Para cada linha i, um la�o para acessar as colunas correspondentes
			printf("[%d][%d]->%d ", i, j, A[i][j]);
	}
	return 0;
}

