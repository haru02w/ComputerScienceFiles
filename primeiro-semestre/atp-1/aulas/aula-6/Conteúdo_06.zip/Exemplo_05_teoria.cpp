#include <stdio.h> 

int main()
{
	char menu[][7] = {"abrir", "editar", "salvar", "sair"};
	int i;
	for(i=0; i<4; i++) 
		puts(menu[i]);
	return 0;
}



