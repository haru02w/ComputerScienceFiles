/*1.	Construa um programa para ler uma matriz 4 x 4, conte e 
escreva quantos valores maiores que 10 ela possui.*/
#include <stdio.h>
#define d 4
int main()
{   
  int cont=0, matriz[d][d];

  printf("\n\t\tEntre com os %d valores da matriz %dx%d:\n\n ",d*d,d,d);

  for (int lin = 0; lin<d; lin++)
  {
    for (int col = 0; col<d; col++)
    { 
		//Leitura dos dados
  	  printf("\nDigite o valor para matriz[%d][%d]: ",lin,col); 
      scanf("%d", &matriz[lin][col]);
      //acumula se valor � maior que 10
      if (matriz[lin][col] > 10)
        cont = cont + 1;
    }
  }
  printf("\nQuantidade de valores maiores que 10: %d", cont);
  //system ("pause");
  return 0;
}


