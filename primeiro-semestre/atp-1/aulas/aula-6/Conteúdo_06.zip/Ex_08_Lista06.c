/*Exerc�cio 8 da Lista 6 de ATP I
8. Construa um programa para gerar automaticamente n�meros entre 0 e 99 de uma cartela de bingo. Sabendo que cada 
cartela dever� conter 5 linhas de 5 n�meros, gere estes dados de modo que n�o tenha n�meros repetidos dentro das cartelas. 
O programa deve exibir na tela a cartela gerada. */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define n 5

int main()
{
  int cartela[n][n], aux[25], pos = 0, sorteio, flag = 0;

  srand(time(NULL));

  for(int i = 0; i < n; i++)
  {
  	
    for(int j = 0; j < n; j++)
	{
      
      if(pos == 0) //teste para armazenar o primeiro n�mero gerado
	  {
        sorteio = rand() % 100;
        cartela[i][j] = sorteio; //armazena n�mero gerado na matriz, cartela
        aux[pos] = sorteio;
        pos++;
      }
      else
	  {
        do{
          flag = 0;
          sorteio = rand() % 100;
          for(int k = 0; k < pos; k++)
		  {
            if(aux[k] == sorteio) //verifica n�mero repetido
			   flag = 1;
          }
        }while(flag == 1);
        aux[pos] = sorteio; //armazena n�mero gerado no vetor (sem repeti��es)
        pos++;
        cartela[i][j] = sorteio; //armazena n�mero gerado na matriz, cartela
      }
    }
  }

  //Apresenta matriz do bingo na tela
  printf("Cartela bingo - gerada automaticamente (intervalo 0 a 99): \n");
  for(int i = 0; i < n; i++)
  {
    printf("\n");
    for(int j = 0; j < n; j++)
      printf("%d ",cartela[i][j]);
  }
  return 0;
}
