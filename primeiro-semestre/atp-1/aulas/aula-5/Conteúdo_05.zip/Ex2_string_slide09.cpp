#include <stdio.h>

int main()
{
  char str1[21];
  puts("\nDigite uma palavra: ");
  scanf("%s",str1);
  puts(str1);
  return 0;
}
