
//Tipos exportados
//----------------------------------
typedef struct no *No;
typedef struct grafo *Grafo;
//----------------------------------

//Defini��o das fun��es
//----------------------------------
No criaNo(int id, int val);

void addNo(No n, int id, int val);

void imprimeNo(No n);

Grafo criaGrafo();

void readGraph(Grafo G, const char *filename);

void printGraph(Grafo G);
//----------------------------------
