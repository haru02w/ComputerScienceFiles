#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0
#define boolean int
#define MAX 101

char pilha[MAX]; //Pilha = conjunto de caracteres (uma string)
int topo;        //�ndice do topo

//Fun��es simples para manusear uma pilha
//----------------------------------------
void Define(void) 
{
   topo = -1;
}

void Push(char x) 
{
   topo++;
   pilha[topo] = x;
}

char Pop(void) 
{
   char c = pilha[topo];
   topo--;
   return c;
} 

boolean Vazia(void) 
{
   return (topo == -1);
}
//----------------------------------------

/* TRUE se a string cont�m uma seq. v�lida (par�nteses + colchetes), FALSE, c.c.*/
boolean SequenciaValida(char s[]) {
   int i;
   Define();
   for (i = 0; s[i] != '\0'; ++i) 
   {
      char c;
      switch (s[i]) 
	  {
         case ')': if (Vazia()) return FALSE;
                   c = Pop(); //Desempilha se encontrar par�nteses � direita
				   if (c != '(') return FALSE;
                   break;     //Novo par�nteses entrando, ent�o n�o faz nada
         case ']': if (Vazia()) return FALSE;
                   c = Pop(); //Desempilha se encontrar colchetes � direita
                   if (c != '[') return FALSE;
                   break;     //Novo colchetes entrando, ent�o n�o faz nada
         default:  Push(s[i]);
      }
   }
   return Vazia();
}


//Principal
int main()
{		
	char sequencia[MAX];
	
	printf("Digite uma sequencia de par�nteses e colchetes: ");
	scanf("%s", sequencia);
	
	if(SequenciaValida(sequencia))
	  printf("Sequencia valida!");
	else
	  printf("Sequencia invalida");
	  
	return 0;	  
}
