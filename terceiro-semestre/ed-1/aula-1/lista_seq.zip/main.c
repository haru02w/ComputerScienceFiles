#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main(int argc, char *argv[])
{
  //Preencher aqui um exemplo pr�tico que utilizar parte das opera��es da lista sequencial
  
  system("PAUSE");
  return 0;
}

