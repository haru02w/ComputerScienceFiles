#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

int main(int argc, char *argv[])
{
  //Preencher aqui
  
  system("PAUSE");
  return 0;
}

