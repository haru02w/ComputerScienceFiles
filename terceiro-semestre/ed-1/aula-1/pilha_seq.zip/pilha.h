#define MAX 1000    //estimativa para tamanho m�ximo
#define TRUE 1      //define tipo boleano
#define FALSE 0
#define boolean int
#define indice int

//Estruturas e tipos empregados
//------------------------------------------------------
//Tipo chave
typedef int tipo_chave; 

//Tipo registro
typedef struct
{
   char nome[30];
   //... (caso tenha mais campos)
} tipo_dado;

//Tipo elemento (registro + chave)
typedef struct
{
   //tipo_chave chave;
   tipo_dado info;
} tipo_elem;

//Tipo lista (seq. encadeada)
typedef struct
{
   tipo_elem A[MAX+1];
   indice topo;
} pilha;
//-------------------------------------------


//Declara��es de fun��es/opera��es
//------------------------------------------------------
//Cria pilha vazia (deve ser usada antes de qualquer outra opera��o)
void Define(pilha *p);

//Insere item no topo da pilha. Retorna true se sucesso, false c.c.
boolean Push(tipo_dado elem, pilha *p);

//Retorna true se pilha � vazia, false c.c.
boolean Vazia(pilha *p);

//Reinicializa pilha
void Desvaziar(pilha *p);

//Devolve o elemento do topo sem remove-lo. Chamada apenas se pilha � n�o vazia
tipo_elem top(pilha *p);

//Remove item do topo da pilha. Chamada apenas se pilha � n�o vazia
void Pop_up(pilha *p);

//Remove e retorna o item do topo da pilha. Chamada apenas se pilha nao vazia
tipo_elem pop(pilha *p);
//------------------------------------------------------

