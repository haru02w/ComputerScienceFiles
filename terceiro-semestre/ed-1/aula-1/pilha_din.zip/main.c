#include <stdio.h>
#include <stdlib.h>
#include "pilha_din.h"

int main(int argc, char *argv[]) 
{
	//Blabla....
	return 0;
}
