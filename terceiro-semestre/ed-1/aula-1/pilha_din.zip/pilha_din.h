#define TRUE 1      
#define FALSE 0
#define boolean int //tipo boleano

//Estruturas e tipos
//------------------------------------------------------
//Tipo registro
typedef struct
{
   char nome[30];
   //... (caso tenha mais campos)
} tipo_dado;

//Tipo elemento (unidade dinamica)
typedef struct elem
{
  tipo_dado info;
  struct elem *lig;
} tipo_elem;

//Tipo pilha
typedef struct
{
  tipo_elem *topo;
} pilha;
//------------------------------------------------------

//Declara��es de fun��es/opera��es
//------------------------------------------------------
//Cria uma pilha p vazia
void Define(pilha *p);

//Insere x no topo da pilha p
boolean Push(tipo_dado x, pilha *p);

//Testa se a pilha p est� vazia
boolean Vazia(pilha *p);

//Acessa o elemento do topo da pilha p, sem remove-lo
tipo_elem *Topo(pilha *p);

//Remove o elemento no topo de p sem retornar valor (desempilha v.1) 
void Pop_up(pilha *p);

//Remove e retorna o elemento (todo o registro) eliminado (desempilha v.2)
tipo_elem *Pop(pilha *p);
//------------------------------------------------------

