#include <stdlib.h>     //Para usar malloc, free, exit ...
#include <stdio.h>      //Caso necessite usar printf ,... 
#include "pilha_din.h"  //Carrega o arquivo .h criado

//Opera��es
//-------------------------------------------
//Cria uma pilha p vazia
void Define(pilha *p)
{
   p->topo = NULL;
}

//Insere x no topo da pilha p (empilha): Push(x, p)
boolean Push(tipo_dado x, pilha *p)
{
   tipo_elem *q = malloc(sizeof(tipo_elem));
   
   if (q == NULL)  //Nao possui mem�ria dispon�vel (esta cheio)
      return FALSE;
   
   //Insere x e faz as liga��es necess�rias
   q->info = x;
   q->lig = p->topo;
   p->topo = q;
   
   return TRUE;
}

//Testa se a pilha p est� vazia
boolean Vazia (pilha *p)
{
   return (p->topo == NULL);
}

//Acessa o elemento do topo da pilha (mas sem remove-lo)
//Obs: testar antes da chamada se a pilha n�o est� vazia
tipo_elem *Topo(pilha *p)
{
   return p->topo;
}

//Remove o elemento no topo de p sem retornar valor (desempilha v.1) 
//Obs: testar antes se pilha n�o est� vazia.
void Pop_up(pilha *p)
{
   tipo_elem *q = p->topo;
   p->topo = p->topo->lig;
   free(q);
}

//Remove e retorna o elemento (todo o registro) eliminado (desempilha v.2)
//Obs: testar antes se pilha n�o est� vazia
tipo_elem *Pop(pilha *p)
{
   tipo_elem *q = p->topo;
   p->topo = p->topo->lig;
   return q;
}

