#include <stdlib.h>     //Para usar malloc, free, exit ...
#include <stdio.h>      //Para usar printf ,... 
#include "fila_din.h"   //Carrega o arquivo .h criado

//Implementa��es das opera��es
//------------------------------------------------------
//Cria uma fila vazia (em geral, usado antes de qualquer operacao)
void Definir(fila *q)
{
   q->inicio = NULL;
   q->fim = NULL;
}

//Verif. fila vazia (retorna true se fila vazia, false c.c.)
boolean Vazia(fila *q)
{	
   return (q->inicio == NULL);
}

/*Reinicializa uma fila existente q como uma fila vazia 
removendo todos os seus elementos.*/
void Tornar_vazia(fila *q)
{
   tipo_elem *ndel, *nextno;
   
   if(!Vazia(q))
   {
      nextno = q->inicio;
      while (nextno != NULL)
	  {
         ndel = nextno;
         nextno = nextno->lig;
         free(ndel);
      }
   }
   
   Definir(q);
}

/*Adiciona um elemento no fim da fila q. (retorna true se 
opera��o realizada com sucesso, false caso contr�rio)*/
boolean Inserir(fila *q, tipo_dado info)
{
   tipo_elem *p;
   
   p = malloc(sizeof(tipo_elem));
   if (p == NULL)
      return FALSE;

   p->info = info;
   p->lig = NULL;

   if (Vazia(q))
      q->inicio = p;
   else
      q->fim->lig = p;
   
   q->fim = p;
   return TRUE;
}

/*Remove um elemento do in�cio da fila q (retorna true se 
opera��o realizada com sucesso, false caso contr�rio)*/
boolean Remover(fila *q, tipo_dado *info)
{
   tipo_elem *p;
   
   if (Vazia(q))
      return FALSE;
   
   p = q->inicio;
   *info = p->info;
   q->inicio = p->lig;

   if (q->inicio == NULL)
      q->fim = NULL;
   
   free(p);
   return TRUE;
}

//Retorna o tamanho da fila
int Tamanho(fila *q)
{
   tipo_elem *p;
   int cont = 0;
   
   p = q->inicio;
   while(p != NULL)
   {
      cont ++;
      p = p->lig;
   }

   return cont;
}

/*Mostra o come�o da fila sem remover o elemento (retorna true 
se opera��o realizada com sucesso, false caso contr�rio)*/
boolean Inicio_fila(fila *q, tipo_dado *elem)
{
   if (Vazia(q))
      return FALSE;
   
   *elem = q->inicio->info;
   return TRUE;
}
