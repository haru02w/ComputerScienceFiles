#define TRUE 1      
#define FALSE 0
#define boolean int   //define tipo boleano

//Estruturas e tipos
//-------------------------------------------
//Tipo registro
typedef struct
{
   char nome[30];
   //... (caso tenha mais campos)
} tipo_dado;

//Tipo elemento (unidade de elemento: p/ impl. din�mica)
typedef struct elem
{
   tipo_dado info;
   struct elem *lig;
} tipo_elem;

//Tipo fila
typedef struct
{
   tipo_elem *inicio;
   tipo_elem *fim;
} fila;
//------------------------------------------------------


//Declara��es de fun��es/opera��es
//------------------------------------------------------
//Cria uma fila vazia
void Definir(fila *q);

//Verif. fila vazia (retorna true se fila vazia, false c.c.)
boolean Vazia(fila *q);

//Reinicializa uma fila existente como uma fila vazia 
void Tornar_vazia(fila *q);

//Adiciona elem. no fim da fila (retorna true se sucesso, false c.c.)
boolean Inserir(fila *q, tipo_dado info);

//Remove elem. do in�cio da fila (retorna true se sucesso, false c.c.)
boolean Remover(fila *q, tipo_dado *info);

//Retorna o tamanho da fila
int Tamanho(fila *q);

//Mostra o come�o da fila sem remover o elem. (retorna true se sucesso, false c.c.)
boolean Inicio_fila(fila *q, tipo_dado *item);
//------------------------------------------------------

