#include <stdio.h>
#include <stdlib.h>
#include "fila_din.h"

int main() 
{
	//Aplica��o aqui da fila
	return 0;
}
