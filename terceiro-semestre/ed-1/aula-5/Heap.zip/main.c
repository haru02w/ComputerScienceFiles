#include <stdio.h>
#include <stdlib.h>
#include "prioridade.h"

int main() {
	
	//Cria uma fila de prioridade com tamanho 10
	fp filapri = Criar_fp (10); 
	
	//Preenche elementos aleat�rios
	Tipo_elem elem1 = {10};
	Tipo_elem elem2 = {20};
	Tipo_elem elem3 = {30};
	Tipo_elem elem4 = {1};
	Tipo_elem elem5 = {15};
	
	//Insere na fila os elementos acima
	Insere(filapri, elem1);
	Insere(filapri, elem2);
	Insere(filapri, elem3);
	Insere(filapri, elem4);
	Insere(filapri, elem5);
	
	Imprime_fila (filapri);
	//Heapsort (filapri);
	
	//Imprime a fila
	Imprime_fila (filapri);
	
	//Remove elemento (sempre de maior prioridade)
	printf("Elemento removido: %d\n", Remove_maior(filapri).chave);
	
	//Imprime a fila
	Imprime_fila (filapri);
	
	//Altera a prioridade do segundo n�
	printf("No A[%d] = %d alterado a prioridade p/ %d\n",1,filapri->A[1],25);
	Altera_prioridade(filapri, 1, 25);
	
	printf("Elemento removido: %d\n", Remove_maior(filapri).chave);
	Imprime_fila (filapri);
	printf("Elemento removido: %d\n", Remove_maior(filapri).chave);
	Imprime_fila (filapri);
	
	free(filapri->A);
	free(filapri);
	
	return 0;
}
