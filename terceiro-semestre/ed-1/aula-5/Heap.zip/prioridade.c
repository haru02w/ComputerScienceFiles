#include <stdlib.h>     //Para usar malloc, free, exit ...
#include <stdio.h>      //Para usar printf ,... 
#include "prioridade.h"

//Opera��es
//--------------------------
//Verifica se a fila de prioridade est� vazia
int Vazia(fp filapri) {
    return (filapri->n == 0);
}

//Verifica se a fila de prioridade est� cheia
int Cheia(fp filapri) {
    return (filapri->n == filapri->tam);
}

//Permuta dois elementos (por refer�ncia, via ponteiros)
void Permuta (Tipo_elem *a, Tipo_elem *b) {	
	Tipo_elem aux = *a;
	*a = *b;
	*b = aux;	
}

//Cria fila de prioridade (aloca array na mem�ria)
fp Criar_fp (int tam) {	
	fp filapri = malloc(sizeof(Fila_pri));
	
	filapri->A = malloc(tam*sizeof(Tipo_elem));
	filapri->n = 0;
	filapri->tam = tam;
	
	return filapri;
}

//Insere um novo elemento na fp
void Insere (fp filapri, Tipo_elem elem) {	
	filapri->A[filapri->n] = elem;
	filapri->n++;
	Sobe_no_heap (filapri, filapri->n-1);
}

//Avalia se � necess�rio permutar o �ndice corrente k e seu pai.
void Sobe_no_heap (fp filapri, int k) {
	if (k > 0 && filapri->A[Pai(k)].chave < filapri->A[k].chave){
		Permuta (&filapri->A[k], &filapri->A[Pai(k)]);
		Sobe_no_heap (filapri, Pai(k)); //Sobe um n�vel
	}
}

//Remove o elemento de maior prioridade
Tipo_elem Remove_maior (fp filapri) {	
	Tipo_elem aux = filapri->A[0]; //Copia maior
	//Permuta maior com �ltimo (pq � mais f�cil remover o �ltimo)
	Permuta (&(filapri->A[0]), &(filapri->A[filapri->n-1]));
	filapri->n--;
	
	Desce_no_heap (filapri, 0);
	return aux;
}

//Avalia se � necess�rio permutar �ndice corrente k com algum de seus filhos
void Desce_no_heap (fp filapri, int k) {
	int maior_filho;
	if (F_esq(k) < filapri->n) {
		maior_filho = F_esq(k); //palpite
		if ( F_dir(k) < filapri->n && 
			 filapri->A[F_esq(k)].chave < filapri->A[F_dir(k)].chave )
			maior_filho = F_dir(k);
		if (filapri->A[k].chave < filapri->A[maior_filho].chave) {
			Permuta (&filapri->A[k], &filapri->A[maior_filho]);
			Desce_no_heap (filapri, maior_filho);
		}
	}
}

//Altera a prioridade de um elemento (k)
void Altera_prioridade (fp filapri, int k, int valor){
	if (filapri->A[k].chave < valor) {
		filapri->A[k].chave = valor;
		Sobe_no_heap (filapri, k);
	} 
	else {
		filapri->A[k].chave = valor;
		Desce_no_heap (filapri, k);
	}	
}

//Constroi heap m�ximo
void Constroi_heap (fp filapri) {
	int k;
	int meio = (filapri->n-1)/2;
	for (k = meio; k >= 0; k--)
		Desce_no_heap (filapri, k);
}

//Heapsort
void Heapsort (fp filapri) {
	int k;
	for (k = (filapri->n-1)/2; k >= 0; k--)
		Desce_no_heap (filapri, k);
		
	k = filapri->n;	
	while (k > 1) //Extrai o m�ximo 
	{
	 	Permuta (&filapri->A[0], &filapri->A[k-1]);
	 	k--;
	 	Desce_no_heap (filapri, 0);
	}
}

//Imprime os elementos de uma fila de prioridade
void Imprime_fila (fp filapri) {
    printf("Fila de prioridade: ");
    int i;
	for(i = 0; i < filapri->n; i++) {
        printf("%d ", filapri->A[i].chave);
    }
    printf("\n");
}
//--------------------------

