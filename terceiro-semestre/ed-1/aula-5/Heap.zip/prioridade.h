
//Fun��es auxiliares
#define Pai(i) ((i-1)/2)
#define F_esq(i) (2*i+1) //Filho esquerdo de i
#define F_dir(i) (2*i+2) //Filho direito de i

//EDs
//--------------------------
//Tipo elemento
typedef struct Tipo_elem {
	int chave;
	//char nome[100]; //demais atributos
} Tipo_elem;

//Fila de prioridade
typedef struct Fila_pri {
	Tipo_elem *A;
	int n;        //elementos preenchidos
	int tam;      //tamanho m�ximo de A
} Fila_pri;

typedef struct Fila_pri *fp;
//--------------------------


//Prot�tipos das opera��es
int Vazia (fp filapri);

int Cheia (fp filapri);

void Permuta (Tipo_elem *a, Tipo_elem *b);

fp Cria_fp (int tam);

void Insere (fp filapri, Tipo_elem elem);

void Sobe_no_heap (fp filapri, int k);

Tipo_elem Remove_maior (fp filapri);

void Desce_no_heap (fp filapri, int k);

void Altera_prioridade (fp filapri, int k, int valor);

void Constroi_heap (fp filapri);

void Heapsort (fp filapri);

void Imprime_fila (fp filapri);
